<?php
    define('SERVER', 'localhost');
    define('USER', 'root');
    define('PASSWORD', '');
    define('DATABASE', 'basemvc24');
    define('CHARSET', 'utf-8');
?>