<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/datatables.min.css">
<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/all.min.css">
<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/select2.min.css">
<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/select2-bootstrap-5-theme.min.css">
<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/table.css">
<link rel="stylesheet" href="/semana5/tallermvcphp/assets/css/index.css">
 