interfaz PHP BACKEND
para borrar DETALLE