<!-- Modal Agregar Factura -->
 <div class="modal fade bd-example-modal-lg" id="agregarConcepto" tabindex="-1"role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
 <div class="modal-dialog modal-lg" role="document">
 <div class="modal-content">
 <div class="modal-header">
 <h4 class="modal-title" id="myModalLabel"><i class="fa fa-edit"></i>Agregando concepto</h4>
 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
 </div>
 <div class="modal-body">

 <div id="loader" style="position: absolute; text-align: center; top:55px; width: 100%;display:none;"></div><!-- Carga gif animado -->
 <div id="outer_div" ></div><!-- Datos ajax Final -->
 </div>
 </div>
</div>
</div>